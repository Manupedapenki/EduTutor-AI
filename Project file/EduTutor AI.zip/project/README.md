# EduTutor AI - Personalized Learning Assistant

A beautiful, modern web application that provides personalized AI-powered tutoring across multiple subjects. Built with React, TypeScript, and Tailwind CSS.

## 🌟 Features

### Core Functionality
- **Subject Selection**: Choose from Mathematics, Science, and History
- **AI Chat Interface**: Interactive conversations with personalized explanations
- **Progress Tracking**: Visual progress dashboard with completion rates and streaks
- **Interactive Quizzes**: Subject-specific quizzes with instant feedback
- **Mock User Authentication**: Simulated user system for demonstration

### Technical Features
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices
- **Modern UI/UX**: Beautiful gradient designs and smooth animations
- **Modular Architecture**: Well-organized, maintainable codebase
- **TypeScript**: Full type safety throughout the application
- **Mock AI Integration**: Simulated AI responses based on subject and keywords

## 🚀 Getting Started

### Prerequisites
- Node.js (version 16 or higher)
- npm or yarn package manager

### Installation

1. **Clone or download the project**
   ```bash
   # The project is already set up in your current directory
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   - Navigate to `http://localhost:5173`
   - The application will automatically reload when you make changes

## 📁 Project Structure

```
src/
├── components/           # React components
│   ├── Header.tsx       # Application header with user info
│   ├── SubjectSelector.tsx # Subject selection interface
│   ├── ChatInterface.tsx   # AI chat functionality
│   ├── ProgressDashboard.tsx # Progress tracking display
│   └── QuizModal.tsx    # Interactive quiz component
├── services/            # Business logic and API simulation
│   ├── aiService.ts     # Mock AI response generation
│   └── progressService.ts # Progress tracking logic
├── types/               # TypeScript type definitions
│   └── index.ts         # All application types
├── utils/               # Utility functions and mock data
│   └── mockData.ts      # Sample data for demonstration
└── App.tsx              # Main application component
```

## 🎯 How to Use

### 1. Subject Selection
- Start by choosing a subject (Math, Science, or History)
- Each subject has its own specialized AI tutor
- The interface will adapt to your selected subject

### 2. Interactive Learning
- Ask questions in natural language
- Receive personalized AI explanations
- Get learning tips specific to your chosen subject
- View your progress in real-time

### 3. Progress Tracking
- Monitor completion rates across all subjects
- Track learning streaks and achievements
- View detailed progress breakdowns

### 4. Quizzes
- Take subject-specific quizzes
- Get instant feedback on answers
- Learn from detailed explanations

## 🛠️ Customization

### Adding New Subjects
1. Update the `subjects` array in `src/utils/mockData.ts`
2. Add corresponding AI responses in `src/services/aiService.ts`
3. Include progress data in `mockProgress` array

### Modifying AI Responses
- Edit `aiService.ts` to customize AI behavior
- Add new keywords and responses for better interaction
- Adjust response generation logic

### Styling Changes
- All styles use Tailwind CSS classes
- Colors and themes can be modified in component files
- Responsive breakpoints are already configured

## 🔧 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint for code quality

## 🎨 Design System

### Colors
- **Primary**: Blue (#3B82F6) - Main actions and highlights
- **Secondary**: Purple (#8B5CF6) - Accents and gradients
- **Success**: Green (#10B981) - Positive feedback
- **Warning**: Yellow (#F59E0B) - Tips and warnings
- **Error**: Red (#EF4444) - Error states

### Typography
- **Headings**: Bold, clear hierarchy
- **Body**: Readable font sizes with proper line spacing
- **Interactive**: Hover states and transitions

## 🚀 Production Deployment

### Build for Production
```bash
npm run build
```

The `dist` folder will contain the optimized production build.

### Deployment Options
- **Netlify**: Drag and drop the `dist` folder
- **Vercel**: Connect your repository for automatic deployments
- **GitHub Pages**: Use the built files for static hosting

## 🔮 Future Enhancements

### Potential Integrations
- **Real AI APIs**: Connect to OpenAI GPT-4 or Hugging Face models
- **Database**: Add PostgreSQL or MongoDB for persistent data
- **Authentication**: Implement real user authentication
- **LMS Integration**: Connect to Canvas, Blackboard, or Moodle

### Feature Expansions
- Voice interaction capabilities
- Video explanations and tutorials
- Collaborative learning features
- Advanced analytics and reporting
- Mobile app version

## 🐛 Troubleshooting

### Common Issues

1. **Port already in use**
   ```bash
   # Kill process on port 5173
   npx kill-port 5173
   npm run dev
   ```

2. **Dependencies not installing**
   ```bash
   # Clear cache and reinstall
   rm -rf node_modules package-lock.json
   npm install
   ```

3. **TypeScript errors**
   ```bash
   # Check for type issues
   npm run build
   ```

## 📚 Learning Resources

### For Beginners
- [React Documentation](https://react.dev/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)

### For Advanced Users
- [Vite Configuration](https://vitejs.dev/config/)
- [React Hooks Patterns](https://react.dev/reference/react)
- [TypeScript Advanced Types](https://www.typescriptlang.org/docs/handbook/2/types-from-types.html)

## 🤝 Contributing

This is a demonstration project, but contributions are welcome:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🎉 Acknowledgments

- Icons provided by [Lucide React](https://lucide.dev/)
- Images from [Pexels](https://www.pexels.com/)
- Built with [Vite](https://vitejs.dev/) and [React](https://react.dev/)
- Styled with [Tailwind CSS](https://tailwindcss.com/)

---

**Happy Learning! 🎓**