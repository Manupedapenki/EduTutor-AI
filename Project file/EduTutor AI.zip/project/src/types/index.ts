export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  subject?: string;
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
}

export interface Progress {
  subject: string;
  completedLessons: number;
  totalLessons: number;
  currentStreak: number;
  lastActivity: Date;
  skillLevel: 'Beginner' | 'Intermediate' | 'Advanced';
}

export interface Quiz {
  id: string;
  subject: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface QuizResult {
  quizId: string;
  selectedAnswer: number;
  isCorrect: boolean;
  timestamp: Date;
}