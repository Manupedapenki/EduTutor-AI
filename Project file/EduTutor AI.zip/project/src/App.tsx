import React, { useState } from 'react';
import { Play, BarChart3, MessageSquare } from 'lucide-react';
import Header from './components/Header';
import SubjectSelector from './components/SubjectSelector';
import ChatInterface from './components/ChatInterface';
import ProgressDashboard from './components/ProgressDashboard';
import QuizModal from './components/QuizModal';
import { Subject, QuizResult } from './types';
import { mockUser, subjects, mockQuizzes } from './utils/mockData';
import { getStudentProgress } from './services/progressService';

type View = 'subjects' | 'chat' | 'progress';

function App() {
  const [currentView, setCurrentView] = useState<View>('subjects');
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [currentQuiz, setCurrentQuiz] = useState(mockQuizzes[0]);
  const [progressData, setProgressData] = useState(getStudentProgress());

  const handleSubjectSelect = (subject: Subject) => {
    setSelectedSubject(subject);
    setCurrentView('chat');
  };

  const handleQuizComplete = (result: QuizResult) => {
    console.log('Quiz completed:', result);
    // Refresh progress data
    setProgressData(getStudentProgress());
  };

  const handleProfileClick = () => {
    console.log('Profile clicked');
  };

  const startQuiz = () => {
    if (selectedSubject) {
      const subjectQuiz = mockQuizzes.find(q => q.subject === selectedSubject.name);
      if (subjectQuiz) {
        setCurrentQuiz(subjectQuiz);
        setShowQuiz(true);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={mockUser} onProfileClick={handleProfileClick} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation */}
        <div className="flex items-center justify-between mb-8">
          <nav className="flex space-x-1 bg-white rounded-lg p-1 shadow-sm border border-gray-200">
            <button
              onClick={() => setCurrentView('subjects')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                currentView === 'subjects'
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <Play className="h-4 w-4" />
              <span>Subjects</span>
            </button>
            <button
              onClick={() => setCurrentView('chat')}
              disabled={!selectedSubject}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                currentView === 'chat'
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed'
              }`}
            >
              <MessageSquare className="h-4 w-4" />
              <span>Chat</span>
            </button>
            <button
              onClick={() => setCurrentView('progress')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                currentView === 'progress'
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <BarChart3 className="h-4 w-4" />
              <span>Progress</span>
            </button>
          </nav>

          {/* Quick Actions */}
          {currentView === 'chat' && selectedSubject && (
            <button
              onClick={startQuiz}
              className="flex items-center space-x-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
            >
              <Play className="h-4 w-4" />
              <span>Quick Quiz</span>
            </button>
          )}
        </div>

        {/* Main Content */}
        <div className="space-y-8">
          {currentView === 'subjects' && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <SubjectSelector
                subjects={subjects}
                selectedSubject={selectedSubject}
                onSubjectSelect={handleSubjectSelect}
              />
            </div>
          )}

          {currentView === 'chat' && selectedSubject && (
            <div className="h-[600px]">
              <ChatInterface
                selectedSubject={selectedSubject}
                user={mockUser}
              />
            </div>
          )}

          {currentView === 'progress' && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <ProgressDashboard progressData={progressData} />
            </div>
          )}
        </div>

        {/* Welcome Message for New Users */}
        {currentView === 'subjects' && !selectedSubject && (
          <div className="mt-12 text-center">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-8 text-white">
              <h2 className="text-3xl font-bold mb-4">Welcome to EduTutor AI!</h2>
              <p className="text-xl text-blue-100 mb-6">
                Your personalized learning journey starts here. Choose a subject to begin exploring!
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
                <div className="bg-white bg-opacity-20 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">🤖 AI-Powered</h3>
                  <p className="text-sm text-blue-100">Get personalized explanations tailored to your learning style</p>
                </div>
                <div className="bg-white bg-opacity-20 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">📊 Track Progress</h3>
                  <p className="text-sm text-blue-100">Monitor your learning journey and celebrate achievements</p>
                </div>
                <div className="bg-white bg-opacity-20 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">🎯 Interactive Quizzes</h3>
                  <p className="text-sm text-blue-100">Test your knowledge with smart quizzes and instant feedback</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quiz Modal */}
      <QuizModal
        quiz={currentQuiz}
        isOpen={showQuiz}
        onClose={() => setShowQuiz(false)}
        onComplete={handleQuizComplete}
      />
    </div>
  );
}

export default App;