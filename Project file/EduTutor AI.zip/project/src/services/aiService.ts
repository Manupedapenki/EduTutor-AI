import { Message, Subject } from '@/types';

// Mock AI responses based on subject and question content
const aiResponses = {
  math: {
    general: [
      "Great question! Let me break down this mathematical concept step by step...",
      "Mathematics is all about patterns and problem-solving. Here's how I'd approach this...",
      "This is a fundamental concept in mathematics. Let me explain it clearly..."
    ],
    keywords: {
      derivative: "The derivative measures how a function changes as its input changes. Think of it as the slope of a curve at any point.",
      integral: "Integration is the reverse of differentiation. It helps us find areas under curves and solve accumulation problems.",
      algebra: "Algebra uses symbols and letters to represent numbers and quantities in formulas and equations.",
      geometry: "Geometry studies shapes, sizes, and properties of space. It's everywhere around us!"
    }
  },
  science: {
    general: [
      "Science is fascinating! Let me explain this concept with real-world examples...",
      "This is an interesting scientific principle. Here's what's happening...",
      "Science helps us understand the world around us. Let me break this down..."
    ],
    keywords: {
      chemistry: "Chemistry studies matter and the changes it undergoes. Everything around us is made of chemicals!",
      physics: "Physics explores how the universe works, from tiny particles to massive galaxies.",
      biology: "Biology is the study of living things and how they interact with their environment.",
      atom: "Atoms are the building blocks of matter. They're incredibly small but make up everything we see!"
    }
  },
  history: {
    general: [
      "History helps us understand how we got to where we are today. Let me share some context...",
      "This historical event had significant impact. Here's what happened and why it matters...",
      "Understanding history gives us valuable lessons for the present and future..."
    ],
    keywords: {
      war: "Wars have shaped human civilization throughout history, often leading to significant social and political changes.",
      revolution: "Revolutions represent turning points in history where societies undergo fundamental changes.",
      civilization: "Civilizations are complex societies with cities, organized government, and cultural achievements.",
      empire: "Empires are powerful political units that control large territories and diverse populations."
    }
  }
};

export const generateAIResponse = async (message: string, subject: Subject): Promise<string> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
  
  const subjectKey = subject.id as keyof typeof aiResponses;
  const subjectResponses = aiResponses[subjectKey];
  
  // Check for keywords in the message
  const lowerMessage = message.toLowerCase();
  for (const [keyword, response] of Object.entries(subjectResponses.keywords)) {
    if (lowerMessage.includes(keyword)) {
      return `${response}\n\nWould you like me to elaborate on any specific aspect of ${keyword}? I'm here to help you understand this concept thoroughly!`;
    }
  }
  
  // Return a general response
  const generalResponses = subjectResponses.general;
  const randomResponse = generalResponses[Math.floor(Math.random() * generalResponses.length)];
  
  return `${randomResponse}\n\nRegarding your question about "${message}", this is an important topic in ${subject.name}. Let me provide you with a comprehensive explanation that builds on your current understanding.\n\nFeel free to ask follow-up questions - I'm here to ensure you fully grasp this concept!`;
};

export const generatePersonalizedTip = (subject: Subject): string => {
  const tips = {
    math: [
      "Practice problems daily to build muscle memory with mathematical operations.",
      "Try to understand the 'why' behind formulas, not just memorize them.",
      "Use visual aids like graphs and diagrams to understand abstract concepts."
    ],
    science: [
      "Connect scientific concepts to everyday phenomena you observe.",
      "Conduct simple experiments to see principles in action.",
      "Read science news to see how current research applies these concepts."
    ],
    history: [
      "Create timelines to understand the sequence of historical events.",
      "Think about cause and effect relationships in historical events.",
      "Consider different perspectives to understand complex historical situations."
    ]
  };
  
  const subjectTips = tips[subject.id as keyof typeof tips];
  return subjectTips[Math.floor(Math.random() * subjectTips.length)];
};