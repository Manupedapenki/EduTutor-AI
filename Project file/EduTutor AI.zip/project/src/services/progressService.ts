import { Progress, QuizResult } from '@/types';
import { mockProgress } from '@/utils/mockData';

export const getStudentProgress = (): Progress[] => {
  return mockProgress;
};

export const updateProgress = (subject: string, increment: number = 1): Progress => {
  const progress = mockProgress.find(p => p.subject === subject);
  if (progress && progress.completedLessons < progress.totalLessons) {
    progress.completedLessons += increment;
    progress.lastActivity = new Date();
    progress.currentStreak += 1;
    
    // Update skill level based on completion percentage
    const completionRate = progress.completedLessons / progress.totalLessons;
    if (completionRate > 0.8) progress.skillLevel = 'Advanced';
    else if (completionRate > 0.4) progress.skillLevel = 'Intermediate';
    else progress.skillLevel = 'Beginner';
  }
  return progress!;
};

export const calculateCompletionPercentage = (progress: Progress): number => {
  return Math.round((progress.completedLessons / progress.totalLessons) * 100);
};

export const getStreakMessage = (streak: number): string => {
  if (streak >= 7) return `🔥 Amazing ${streak}-day streak!`;
  if (streak >= 3) return `⭐ Great ${streak}-day streak!`;
  if (streak >= 1) return `👍 ${streak}-day streak!`;
  return 'Start your learning streak today!';
};

export const submitQuizResult = (result: QuizResult): void => {
  // In a real app, this would save to a database
  console.log('Quiz result submitted:', result);
  
  // Update progress if quiz was correct
  if (result.isCorrect) {
    // This would typically be determined by the quiz's subject
    updateProgress('Mathematics', 0.5);
  }
};