import { Subject, Progress, Quiz, User } from '@/types';

export const mockUser: User = {
  id: '1',
  name: 'Alex Johnson',
  email: 'alex.johnson@email.com',
  avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2'
};

export const subjects: Subject[] = [
  {
    id: 'math',
    name: 'Mathematics',
    icon: 'Calculator',
    color: 'from-blue-500 to-cyan-500',
    description: 'Algebra, Geometry, Calculus & more'
  },
  {
    id: 'science',
    name: 'Science',
    icon: 'Atom',
    color: 'from-green-500 to-emerald-500',
    description: 'Physics, Chemistry, Biology'
  },
  {
    id: 'history',
    name: 'History',
    icon: 'Clock',
    color: 'from-purple-500 to-pink-500',
    description: 'World History, Ancient Civilizations'
  }
];

export const mockProgress: Progress[] = [
  {
    subject: 'Mathematics',
    completedLessons: 14,
    totalLessons: 20,
    currentStreak: 5,
    lastActivity: new Date('2024-01-15'),
    skillLevel: 'Intermediate'
  },
  {
    subject: 'Science',
    completedLessons: 8,
    totalLessons: 12,
    currentStreak: 3,
    lastActivity: new Date('2024-01-14'),
    skillLevel: 'Beginner'
  },
  {
    subject: 'History',
    completedLessons: 16,
    totalLessons: 18,
    currentStreak: 7,
    lastActivity: new Date('2024-01-16'),
    skillLevel: 'Advanced'
  }
];

export const mockQuizzes: Quiz[] = [
  {
    id: '1',
    subject: 'Mathematics',
    question: 'What is the derivative of x²?',
    options: ['2x', 'x²', '2', 'x'],
    correctAnswer: 0,
    explanation: 'The derivative of x² is 2x using the power rule: d/dx(xⁿ) = n·xⁿ⁻¹'
  },
  {
    id: '2',
    subject: 'Science',
    question: 'What is the chemical symbol for gold?',
    options: ['Go', 'Gd', 'Au', 'Ag'],
    correctAnswer: 2,
    explanation: 'The chemical symbol for gold is Au, derived from the Latin word "aurum"'
  },
  {
    id: '3',
    subject: 'History',
    question: 'In which year did World War II end?',
    options: ['1944', '1945', '1946', '1947'],
    correctAnswer: 1,
    explanation: 'World War II ended in 1945 with the surrender of Japan on September 2, 1945'
  }
];