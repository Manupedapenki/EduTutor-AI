import React from 'react';
import { Calculator, Atom, Clock, ChevronRight } from 'lucide-react';
import { Subject } from '@/types';

interface SubjectSelectorProps {
  subjects: Subject[];
  selectedSubject: Subject | null;
  onSubjectSelect: (subject: Subject) => void;
}

const SubjectSelector: React.FC<SubjectSelectorProps> = ({
  subjects,
  selectedSubject,
  onSubjectSelect
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Calculator':
        return Calculator;
      case 'Atom':
        return Atom;
      case 'Clock':
        return Clock;
      default:
        return Calculator;
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold text-gray-900">Choose Your Subject</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {subjects.map((subject) => {
          const IconComponent = getIcon(subject.icon);
          const isSelected = selectedSubject?.id === subject.id;
          
          return (
            <button
              key={subject.id}
              onClick={() => onSubjectSelect(subject)}
              className={`group relative overflow-hidden rounded-xl p-6 text-left transition-all duration-300 transform hover:scale-105 hover:shadow-lg ${
                isSelected
                  ? 'ring-2 ring-blue-500 shadow-lg'
                  : 'hover:shadow-md'
              }`}
            >
              {/* Background Gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${subject.color} opacity-10 group-hover:opacity-20 transition-opacity duration-300`} />
              
              {/* Content */}
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${subject.color} bg-opacity-20`}>
                    <IconComponent className={`h-6 w-6 bg-gradient-to-r ${subject.color} bg-clip-text text-transparent`} />
                  </div>
                  <ChevronRight className={`h-5 w-5 text-gray-400 transition-transform duration-300 ${isSelected ? 'rotate-90' : 'group-hover:translate-x-1'}`} />
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {subject.name}
                </h3>
                
                <p className="text-sm text-gray-600">
                  {subject.description}
                </p>
                
                {isSelected && (
                  <div className="mt-3 flex items-center space-x-2">
                    <div className="h-2 w-2 bg-blue-500 rounded-full animate-pulse" />
                    <span className="text-xs font-medium text-blue-600">Active</span>
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default SubjectSelector;