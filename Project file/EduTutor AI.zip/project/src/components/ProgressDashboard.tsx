import React from 'react';
import { TrendingUp, Calendar, Award, Target, Clock, BookOpen } from 'lucide-react';
import { Progress } from '@/types';
import { calculateCompletionPercentage, getStreakMessage } from '@/services/progressService';

interface ProgressDashboardProps {
  progressData: Progress[];
}

const ProgressDashboard: React.FC<ProgressDashboardProps> = ({ progressData }) => {
  const totalProgress = progressData.reduce((acc, p) => acc + calculateCompletionPercentage(p), 0) / progressData.length;
  const totalStreak = Math.max(...progressData.map(p => p.currentStreak));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900">Your Learning Progress</h2>
        <div className="text-sm text-gray-500">
          Last updated: {new Date().toLocaleDateString()}
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-6 border border-blue-200">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-500 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-blue-600">Overall Progress</p>
              <p className="text-2xl font-bold text-blue-900">{Math.round(totalProgress)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-6 border border-green-200">
          <div className="flex items-center space-x-3">
            <div className="bg-green-500 p-3 rounded-lg">
              <Award className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-green-600">Current Streak</p>
              <p className="text-2xl font-bold text-green-900">{totalStreak} days</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-6 border border-purple-200">
          <div className="flex items-center space-x-3">
            <div className="bg-purple-500 p-3 rounded-lg">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-purple-600">Subjects Active</p>
              <p className="text-2xl font-bold text-purple-900">{progressData.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Subject Progress */}
      <div className="space-y-4">
        {progressData.map((progress) => {
          const completionPercentage = calculateCompletionPercentage(progress);
          const progressColor = 
            completionPercentage >= 80 ? 'green' :
            completionPercentage >= 50 ? 'blue' : 'yellow';

          return (
            <div key={progress.subject} className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{progress.subject}</h3>
                  <p className="text-sm text-gray-600">
                    {progress.completedLessons} of {progress.totalLessons} lessons completed
                  </p>
                </div>
                <div className="text-right">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                    progress.skillLevel === 'Advanced' ? 'bg-green-100 text-green-800' :
                    progress.skillLevel === 'Intermediate' ? 'bg-blue-100 text-blue-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {progress.skillLevel}
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Progress</span>
                  <span>{completionPercentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-500 bg-${progressColor}-500`}
                    style={{ width: `${completionPercentage}%` }}
                  />
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  <div>
                    <p className="text-xs text-gray-500">Last Activity</p>
                    <p className="text-sm font-medium text-gray-900">
                      {progress.lastActivity.toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Target className="h-4 w-4 text-gray-400" />
                  <div>
                    <p className="text-xs text-gray-500">Streak</p>
                    <p className="text-sm font-medium text-gray-900">
                      {getStreakMessage(progress.currentStreak)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Motivational Message */}
      <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center space-x-3">
          <Clock className="h-6 w-6" />
          <div>
            <h3 className="text-lg font-semibold">Keep up the great work!</h3>
            <p className="text-indigo-100 mt-1">
              You're making excellent progress across all subjects. Consistency is key to mastering new concepts!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressDashboard;