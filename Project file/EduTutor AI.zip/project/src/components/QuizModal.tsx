import React, { useState } from 'react';
import { X, CheckCircle, XCircle, Lightbulb } from 'lucide-react';
import { Quiz, QuizResult } from '@/types';
import { submitQuizResult } from '@/services/progressService';

interface QuizModalProps {
  quiz: Quiz;
  isOpen: boolean;
  onClose: () => void;
  onComplete: (result: QuizResult) => void;
}

const QuizModal: React.FC<QuizModalProps> = ({ quiz, isOpen, onClose, onComplete }) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (selectedAnswer === null) return;

    const result: QuizResult = {
      quizId: quiz.id,
      selectedAnswer,
      isCorrect: selectedAnswer === quiz.correctAnswer,
      timestamp: new Date()
    };

    setQuizResult(result);
    setShowResult(true);
    submitQuizResult(result);
    
    // Auto-close after showing result
    setTimeout(() => {
      onComplete(result);
      handleClose();
    }, 3000);
  };

  const handleClose = () => {
    setSelectedAnswer(null);
    setShowResult(false);
    setQuizResult(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Quick Quiz</h2>
            <p className="text-sm text-gray-600">{quiz.subject}</p>
          </div>
          <button
            onClick={handleClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {!showResult ? (
            <>
              {/* Question */}
              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  {quiz.question}
                </h3>
                
                {/* Options */}
                <div className="space-y-3">
                  {quiz.options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedAnswer(index)}
                      className={`w-full text-left p-4 rounded-lg border-2 transition-all duration-200 ${
                        selectedAnswer === index
                          ? 'border-blue-500 bg-blue-50 text-blue-900'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 rounded-full border-2 ${
                          selectedAnswer === index
                            ? 'border-blue-500 bg-blue-500'
                            : 'border-gray-300'
                        }`}>
                          {selectedAnswer === index && (
                            <div className="w-full h-full rounded-full bg-white scale-50" />
                          )}
                        </div>
                        <span className="font-medium">{String.fromCharCode(65 + index)}.</span>
                        <span>{option}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end">
                <button
                  onClick={handleSubmit}
                  disabled={selectedAnswer === null}
                  className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors font-medium"
                >
                  Submit Answer
                </button>
              </div>
            </>
          ) : (
            /* Result */
            <div className="text-center">
              <div className="mb-6">
                {quizResult?.isCorrect ? (
                  <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                ) : (
                  <XCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
                )}
                
                <h3 className={`text-2xl font-bold mb-2 ${
                  quizResult?.isCorrect ? 'text-green-600' : 'text-red-600'
                }`}>
                  {quizResult?.isCorrect ? 'Correct!' : 'Incorrect'}
                </h3>
                
                <p className="text-gray-600 mb-4">
                  {quizResult?.isCorrect 
                    ? 'Great job! You got it right.' 
                    : `The correct answer was ${String.fromCharCode(65 + quiz.correctAnswer)}.`
                  }
                </p>
              </div>

              {/* Explanation */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-left">
                <div className="flex items-start space-x-3">
                  <Lightbulb className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-blue-900 mb-2">Explanation</h4>
                    <p className="text-blue-800 text-sm">{quiz.explanation}</p>
                  </div>
                </div>
              </div>

              <p className="text-sm text-gray-500 mt-4">
                This window will close automatically in a few seconds...
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuizModal;